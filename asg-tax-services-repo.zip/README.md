# ASG Tax Services Website

Static website ready for GitHub Pages.

**Business**
- ASG Tax Services
- 111 Park St, Lawrence, MA 01841
- 978-902-9018
- asgtaxservices@gmail.com

## Deploy on GitHub Pages
1. Create a new GitHub repo (e.g., `asg-tax-services`)
2. Upload all files from this folder to the repo root
3. Go to **Settings → Pages**
4. Source: **Deploy from a branch** → Branch: `main` → Folder: `/ (root)`
5. Save

## Contact Form
Contact form uses FormSubmit and sends messages to **asgtaxservices@gmail.com**.
The first submission triggers an email verification from FormSubmit.
